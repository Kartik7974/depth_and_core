module LoginsHelper
end
